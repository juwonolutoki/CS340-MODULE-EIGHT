#pragma once
#ifndef SHADER_MANAGER_H
#define SHADER_MANAGER_H

#include <GL/glew.h>  // or GLAD
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>

class ShaderManager {
public:
    ShaderManager() : programID(0) {}
    ~ShaderManager() {
        if (programID) {
            glDeleteProgram(programID);
        }
    }

    void LoadShaders(const std::string& vertexPath, const std::string& fragmentPath) {
        // Load and compile shaders
        GLuint vertexShader = LoadShader(vertexPath, GL_VERTEX_SHADER);
        GLuint fragmentShader = LoadShader(fragmentPath, GL_FRAGMENT_SHADER);

        // Link shaders to create a program
        programID = glCreateProgram();
        glAttachShader(programID, vertexShader);
        glAttachShader(programID, fragmentShader);
        glLinkProgram(programID);

        // Check for linking errors
        GLint success;
        glGetProgramiv(programID, GL_LINK_STATUS, &success);
        if (!success) {
            GLchar infoLog[512];
            glGetProgramInfoLog(programID, 512, nullptr, infoLog);
            std::cerr << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
        }

        // Delete the shaders as they're linked into the program now and no longer necessary
        glDeleteShader(vertexShader);
        glDeleteShader(fragmentShader);
    }

    void Use() {
        glUseProgram(programID);
    }

    GLuint GetProgramID() const {
        return programID;
    }

private:
    GLuint programID;

    GLuint LoadShader(const std::string& filePath, GLenum shaderType) {
        // Read shader code from file
        std::ifstream shaderFile(filePath);
        if (!shaderFile.is_open()) {
            std::cerr << "ERROR::SHADER::FILE_NOT_FOUND: " << filePath << std::endl;
            return 0;
        }

        std::stringstream shaderStream;
        shaderStream << shaderFile.rdbuf();
        std::string shaderCode = shaderStream.str();
        const char* shaderCodeCStr = shaderCode.c_str();

        // Compile shader
        GLuint shaderID = glCreateShader(shaderType);
        glShaderSource(shaderID, 1, &shaderCodeCStr, nullptr);
        glCompileShader(shaderID);

        // Check for compilation errors
        GLint success;
        glGetShaderiv(shaderID, GL_COMPILE_STATUS, &success);
        if (!success) {
            GLchar infoLog[512];
            glGetShaderInfoLog(shaderID, 512, nullptr, infoLog);
            std::cerr << "ERROR::SHADER::COMPILATION_FAILED of type: " << shaderType << "\n" << infoLog << std::endl;
        }

        return shaderID;
    }
};

#endif // SHADER_MANAGER_H
