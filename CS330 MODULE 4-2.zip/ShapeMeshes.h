#pragma once
#ifndef SHAPE_MESHES_H
#define SHAPE_MESHES_H

#include <GL/glew.h>  // or GLAD
#include <vector>
#include <iostream>

class ShapeMeshes {
public:
    ShapeMeshes() : VAO(0), VBO(0) {
        // Create the triangle mesh
        CreateTriangleMesh();
    }

    ~ShapeMeshes() {
        // Clean up the OpenGL resources
        glDeleteVertexArrays(1, &VAO);
        glDeleteBuffers(1, &VBO);
    }

    void Draw() {
        // Bind the VAO and draw the mesh
        glBindVertexArray(VAO);
        glDrawArrays(GL_TRIANGLES, 0, 3); // Drawing a triangle
        glBindVertexArray(0);
    }

private:
    GLuint VAO, VBO;

    void CreateTriangleMesh() {
        // Define the vertices for a triangle
        GLfloat vertices[] = {
            0.0f,  0.5f, 0.0f,  // Vertex 1 (X, Y)
            -0.5f, -0.5f, 0.0f,  // Vertex 2 (X, Y)
            0.5f, -0.5f, 0.0f   // Vertex 3 (X, Y)
        };

        // Generate and bind a Vertex Array Object
        glGenVertexArrays(1, &VAO);
        glBindVertexArray(VAO);

        // Generate and bind a Vertex Buffer Object
        glGenBuffers(1, &VBO);
        glBindBuffer(GL_ARRAY_BUFFER, VBO);

        // Copy the vertex data into the buffer
        glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

        // Define the vertex attributes (position)
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
        glEnableVertexAttribArray(0);

        // Unbind the VBO and VAO
        glBindBuffer(GL_ARRAY_BUFFER, 0);
        glBindVertexArray(0);
    }
};

#endif // SHAPE_MESHES_H

