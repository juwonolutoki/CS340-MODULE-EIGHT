#include "ShaderManager.h"
#include "ShapeMeshes.h"
#include "SceneManager.h"
#include <GLFW/glfw3.h>
#include <iostream>

void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}

int main() {
    // Initialize GLFW
    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        return -1;
    }

    // Create a GLFW window
    GLFWwindow* window = glfwCreateWindow(800, 600, "OpenGL Scene", nullptr, nullptr);
    if (!window) {
        std::cerr << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    // Initialize GLEW or GLAD (make sure you include the necessary headers)
    // Example with GLEW:
    // glewExperimental = GL_TRUE; 
    // glewInit();

    // Create ShaderManager and ShapeMeshes
    ShaderManager shaderManager;
    ShapeMeshes shapeMeshes;

    // Create SceneManager
    SceneManager sceneManager(&shaderManager);

    // Prepare the scene
    sceneManager.PrepareScene();

    // Main render loop
    while (!glfwWindowShouldClose(window)) {
        // Input processing
        sceneManager.ProcessInput(window);

        // Clear the screen
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Render the scene
        sceneManager.RenderScene();

        // Swap buffers
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // Cleanup and exit
    glfwTerminate();
    return 0;
}
