#pragma once
#include "ShaderManager.h"
#include "ShapeMeshes.h"
#include <string>
#include <vector>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>

/***********************************************************
 *  SceneManager
 *
 *  This class contains the code for preparing and rendering
 *  3D scenes, including the shader settings.
 ***********************************************************/
class SceneManager
{
public:
    // constructor
    SceneManager(ShaderManager* pShaderManager);
    // destructor
    ~SceneManager();

    void ProcessInput(GLFWwindow* window);
    void UpdateCamera();

    // properties for loaded texture access
    struct TEXTURE_INFO
    {
        std::string tag;
        uint32_t ID;
    };

    // properties for object materials
    struct OBJECT_MATERIAL
    {
        glm::vec3 diffuseColor;
        glm::vec3 specularColor;
        float shininess;
        std::string tag;
    };

private:
    // pointer to shader manager object
    ShaderManager* m_pShaderManager;
    // pointer to basic shapes object
    ShapeMeshes* m_basicMeshes;
    // total number of loaded textures
    int m_loadedTextures;
    // loaded textures info
    TEXTURE_INFO m_textureIDs[16];
    // defined object materials
    std::vector<OBJECT_MATERIAL> m_objectMaterials;

    // Camera attributes
    glm::vec3 m_cameraPos;
    glm::vec3 m_cameraFront;
    glm::vec3 m_cameraUp;
    float m_yaw;
    float m_pitch;
    float m_movementSpeed;
    float m_zoomSpeed;

    // Mouse input
    double lastX, lastY;
    bool firstMouse;

    // set the transformation values into the transform buffer
    void SetTransformations(
        glm::vec3 scaleXYZ,
        float XrotationDegrees,
        float YrotationDegrees,
        float ZrotationDegrees,
        glm::vec3 positionXYZ);

    // set the color values into the shader
    void SetShaderColor(
        float redColorValue,
        float greenColorValue,
        float blueColorValue,
        float alphaValue);

public:
    void PrepareScene();
    void RenderScene(GLFWwindow* window); // Accept window as parameter
};

// Constructor
SceneManager::SceneManager(ShaderManager* pShaderManager)
    : m_pShaderManager(pShaderManager),
    m_cameraPos(0.0f, 0.0f, 3.0f),
    m_cameraFront(0.0f, 0.0f, -1.0f),
    m_cameraUp(0.0f, 1.0f, 0.0f),
    m_yaw(-90.0f),
    m_pitch(0.0f),
    m_movementSpeed(2.5f),
    m_zoomSpeed(0.1f),
    firstMouse(true)
{
    // Initialize mouse position
    lastX = 400; // Default starting position (centered)
    lastY = 300; // Default starting position (centered)
}

void SceneManager::ProcessInput(GLFWwindow* window)
{
    // Handle camera movement
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        m_cameraPos += m_movementSpeed * m_cameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        m_cameraPos -= m_movementSpeed * m_cameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        m_cameraPos -= glm::normalize(glm::cross(m_cameraFront, m_cameraUp)) * m_movementSpeed;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        m_cameraPos += glm::normalize(glm::cross(m_cameraFront, m_cameraUp)) * m_movementSpeed;

    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        m_cameraPos += m_cameraUp * m_movementSpeed;
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        m_cameraPos -= m_cameraUp * m_movementSpeed;

    // Adjust movement speed with mouse scroll
    double scrollY;
    glfwGetScrollY(window, &scrollY);
    m_movementSpeed += (float)scrollY * m_zoomSpeed;
    m_movementSpeed = glm::clamp(m_movementSpeed, 1.0f, 10.0f); // limit speed

    UpdateCamera();
}

void SceneManager::UpdateCamera()
{
    glm::vec3 front;
    front.x = cos(glm::radians(m_yaw)) * cos(glm::radians(m_pitch));
    front.y = sin(glm::radians(m_pitch));
    front.z = sin(glm::radians(m_yaw)) * cos(glm::radians(m_pitch));
    m_cameraFront = glm::normalize(front);
}

// Call this in your main render loop
void SceneManager::RenderScene(GLFWwindow* window)
{
    ProcessInput(window);

    // Example rendering code (replace with actual rendering logic)
    m_pShaderManager->UseShader(); // Activate your shader
    // Set uniforms for view and projection matrices
    glm::mat4 view = glm::lookAt(m_cameraPos, m_cameraPos + m_cameraFront, m_cameraUp);
    m_pShaderManager->SetUniform("view", glm::value_ptr(view));
    m_pShaderManager->SetUniform("projection", glm::value_ptr(glm::perspective(glm::radians(45.0f), 800.0f / 600.0f, 0.1f, 100.0f)));

    // Other rendering code for shapes and materials goes here...
}

// Destructor
SceneManager::~SceneManager()
{
    // Cleanup if necessary
    // e.g., delete m_basicMeshes if dynamically allocated
}
