///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport - camera, projection
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "SceneManager.h"
#include "ShaderManager.h"
#include "ShapeMeshes.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// Constructor
SceneManager::SceneManager(ShaderManager* shaderManager)
    : m_shaderManager(shaderManager), m_yaw(-90.0f), m_pitch(0.0f), m_cameraSpeed(2.5f) {
    // Initialize camera parameters
    m_cameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
    updateCameraVectors();
}

// Prepare the scene by loading shapes and shaders
void SceneManager::PrepareScene() {
    m_shapeMeshes.LoadShapes(); // Assuming this function initializes shape meshes
    m_shaderManager->LoadShaders(); // Assuming this function loads and compiles shaders
}

// Render the scene
void SceneManager::RenderScene() {
    // Clear the buffers
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Use the shader program
    m_shaderManager->UseShader();

    // Calculate the view matrix
    glm::mat4 view = glm::lookAt(m_cameraPos, m_cameraPos + m_cameraFront, m_cameraUp);
    m_shaderManager->SetUniformMatrix4fv("view", view);

    // Set the projection matrix
    glm::mat4 projection = glm::perspective(glm::radians(45.0f), 800.0f / 600.0f, 0.1f, 100.0f);
    m_shaderManager->SetUniformMatrix4fv("projection", projection);

    // Render shapes
    m_shapeMeshes.RenderShapes(m_shaderManager);
}

// Update camera vectors based on yaw and pitch
void SceneManager::updateCameraVectors() {
    glm::vec3 front;
    front.x = cos(glm::radians(m_yaw)) * cos(glm::radians(m_pitch));
    front.y = sin(glm::radians(m_pitch));
    front.z = sin(glm::radians(m_yaw)) * cos(glm::radians(m_pitch));
    m_cameraFront = glm::normalize(front);

    // Right vector
    glm::vec3 right = glm::normalize(glm::cross(m_cameraFront, glm::vec3(0.0f, 1.0f, 0.0f)));
    m_cameraUp = glm::normalize(glm::cross(right, m_cameraFront));
}

// Call this function to handle camera movement (e.g., keyboard input)
void SceneManager::ProcessInput(GLFWwindow* window) {
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        m_cameraPos += m_cameraSpeed * m_cameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        m_cameraPos -= m_cameraSpeed * m_cameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        m_cameraPos -= glm::normalize(glm::cross(m_cameraFront, m_cameraUp)) * m_cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        m_cameraPos += glm::normalize(glm::cross(m_cameraFront, m_cameraUp)) * m_cameraSpeed;
}

// Update function for handling camera input
void SceneManager::Update() {
    ProcessInput(glfwGetCurrentContext()); // Pass the current window context
}
